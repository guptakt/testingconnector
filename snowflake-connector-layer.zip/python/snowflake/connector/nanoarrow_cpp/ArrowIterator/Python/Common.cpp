//
// Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
//

#include "Common.hpp"

namespace sf {

namespace py {
// this file will be deleted if it is not used in the future
}
}  // namespace sf
